package com.realisticexplosions.render;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.*;
import com.realisticexplosions.client.ExplosionEffectClient;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(value = Dist.CLIENT, modid = "realisticexplosions")
public class ExplosionRenderer {

    // ===================== ТРЯСКА КАМЕРЫ =====================
    @SubscribeEvent
    public static void onCameraSetup(ViewportEvent.ComputeCameraAngles event) {
        if (ExplosionEffectClient.shakePower > 0.01f) {
            event.setYaw(event.getYaw() + ExplosionEffectClient.shakeX);
            event.setPitch(event.getPitch() + ExplosionEffectClient.shakeY);
        }
    }

    // ===================== ВСПЫШКА НА ЭКРАНЕ =====================
    @SubscribeEvent
    public static void onRenderGui(RenderGuiOverlayEvent.Post event) {
        float flash = ExplosionEffectClient.flashAlpha;
        if (flash < 0.01f) return;

        Minecraft mc = Minecraft.getInstance();
        int width = mc.getWindow().getGuiScaledWidth();
        int height = mc.getWindow().getGuiScaledHeight();

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShader(GameRenderer::getPositionColorShader);

        BufferBuilder buffer = Tesselator.getInstance().getBuilder();
        buffer.begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_COLOR);

        int alpha = (int)(flash * 255);
        // Белая вспышка, немного желтоватая
        buffer.vertex(0, 0, 0).color(255, 240, 180, alpha).endVertex();
        buffer.vertex(0, height, 0).color(255, 240, 180, alpha).endVertex();
        buffer.vertex(width, height, 0).color(255, 240, 180, alpha).endVertex();
        buffer.vertex(width, 0, 0).color(255, 240, 180, alpha).endVertex();

        Tesselator.getInstance().end();
        RenderSystem.disableBlend();
    }

    // ===================== УДАРНАЯ ВОЛНА В 3D =====================
    @SubscribeEvent
    public static void onRenderLevel(net.minecraftforge.client.event.RenderLevelStageEvent event) {
        if (event.getStage() != net.minecraftforge.client.event.RenderLevelStageEvent.Stage.AFTER_PARTICLES) return;
        if (ExplosionEffectClient.SHOCKWAVES.isEmpty()) return;

        Minecraft mc = Minecraft.getInstance();
        Vec3 camPos = mc.gameRenderer.getMainCamera().getPosition();
        float partial = event.getPartialTick();

        PoseStack ps = event.getPoseStack();
        ps.pushPose();

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        RenderSystem.setShader(GameRenderer::getPositionColorShader);

        for (ExplosionEffectClient.ShockwaveRing ring : ExplosionEffectClient.SHOCKWAVES) {
            renderShockwaveRing(ps, ring, camPos, partial);
        }

        RenderSystem.enableCull();
        RenderSystem.disableBlend();
        ps.popPose();
    }

    private static void renderShockwaveRing(PoseStack ps, ExplosionEffectClient.ShockwaveRing ring,
                                             Vec3 camPos, float partial) {
        double dx = ring.center.x - camPos.x;
        double dy = ring.center.y - camPos.y;
        double dz = ring.center.z - camPos.z;

        ps.pushPose();
        ps.translate(dx, dy, dz);

        float radius = ring.getPartialRadius(partial);
        float alpha = ring.alpha * 0.6f;
        int a = (int)(alpha * 255);

        // Внешнее кольцо — белое с голубым оттенком
        int r = 200, g = 220, b = 255;

        int segments = 48;
        float thickness = 0.6f + radius * 0.05f;

        BufferBuilder buffer = Tesselator.getInstance().getBuilder();
        buffer.begin(VertexFormat.Mode.TRIANGLE_STRIP, DefaultVertexFormat.POSITION_COLOR);

        for (int i = 0; i <= segments; i++) {
            double angle = (2.0 * Math.PI * i) / segments;
            float cx = (float)(Math.cos(angle));
            float cz = (float)(Math.sin(angle));

            // Внешний радиус
            buffer.vertex(cx * (radius + thickness), 0, cz * (radius + thickness))
                .color(r, g, b, 0).endVertex();
            // Центральный (яркий)
            buffer.vertex(cx * radius, 0, cz * radius)
                .color(r, g, b, a).endVertex();
        }
        // Закрытие внутрь
        for (int i = 0; i <= segments; i++) {
            double angle = (2.0 * Math.PI * i) / segments;
            float cx = (float)(Math.cos(angle));
            float cz = (float)(Math.sin(angle));

            buffer.vertex(cx * radius, 0, cz * radius)
                .color(r, g, b, a).endVertex();
            buffer.vertex(cx * (radius - thickness * 0.5f), 0, cz * (radius - thickness * 0.5f))
                .color(r, g, b, 0).endVertex();
        }

        Tesselator.getInstance().end();
        ps.popPose();
    }
}
