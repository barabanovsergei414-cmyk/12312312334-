package com.realisticexplosions.sound;

import com.realisticexplosions.RealisticExplosions;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class SoundRegistry {

    public static final DeferredRegister<SoundEvent> SOUNDS =
        DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, RealisticExplosions.MODID);

    // power < 0.5 (1 TNT вдалеке)
    public static final RegistryObject<SoundEvent> EXPLOSION_SMALL =
        SOUNDS.register("explosion_small",
            () -> SoundEvent.createVariableRangeEvent(
                new ResourceLocation(RealisticExplosions.MODID, "explosion_small")));

    // power 0.5 - 1.5 (1-2 TNT)
    public static final RegistryObject<SoundEvent> EXPLOSION_MEDIUM =
        SOUNDS.register("explosion_medium",
            () -> SoundEvent.createVariableRangeEvent(
                new ResourceLocation(RealisticExplosions.MODID, "explosion_medium")));

    // power 1.5 - 3.0 (несколько TNT)
    public static final RegistryObject<SoundEvent> EXPLOSION_LARGE =
        SOUNDS.register("explosion_large",
            () -> SoundEvent.createVariableRangeEvent(
                new ResourceLocation(RealisticExplosions.MODID, "explosion_large")));

    // power > 3.0 (много TNT)
    public static final RegistryObject<SoundEvent> EXPLOSION_HUGE =
        SOUNDS.register("explosion_huge",
            () -> SoundEvent.createVariableRangeEvent(
                new ResourceLocation(RealisticExplosions.MODID, "explosion_huge")));
}
