package com.realisticexplosions.particle;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.*;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class ExplosionSmokeParticle extends TextureSheetParticle {

    private final float startSize;

    private ExplosionSmokeParticle(ClientLevel level, double x, double y, double z,
                                    double vx, double vy, double vz) {
        super(level, x, y, z, vx, vy, vz);
        float gray = 0.04f + (float)(random.nextDouble() * 0.12);
        this.rCol = gray; this.gCol = gray; this.bCol = gray;
        this.alpha = 0.8f;
        // Долгий дым: 8-14 секунд
        this.lifetime = 160 + random.nextInt(120);
        this.startSize = 0.5f + (float)(random.nextDouble() * 1.0);
        this.quadSize = startSize;
        this.gravity = -0.003f;
        this.xd = vx; this.yd = vy; this.zd = vz;
    }

    @Override
    public void tick() {
        this.xo = this.x; this.yo = this.y; this.zo = this.z;
        float ratio = (float)this.age / this.lifetime;
        // Расширяется
        this.quadSize = startSize * (1.0f + ratio * 3.0f);
        // Гаснет в последние 40% жизни
        if (ratio > 0.6f) {
            this.alpha = 0.8f * (1.0f - (ratio - 0.6f) / 0.4f);
        }
        this.yd += 0.001f;
        this.xd *= 0.98f; this.zd *= 0.98f;
        this.move(this.xd, this.yd, this.zd);
        if (this.age++ >= this.lifetime) this.remove();
    }

    @Override
    public ParticleRenderType getRenderType() {
        return ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT;
    }

    @OnlyIn(Dist.CLIENT)
    public static class Factory implements ParticleProvider<SimpleParticleType> {
        private final SpriteSet sprites;
        public Factory(SpriteSet sprites) { this.sprites = sprites; }

        @Override
        public Particle createParticle(SimpleParticleType type, ClientLevel level,
                                        double x, double y, double z,
                                        double vx, double vy, double vz) {
            ExplosionSmokeParticle p = new ExplosionSmokeParticle(level, x, y, z, vx, vy, vz);
            p.pickSprite(sprites);
            return p;
        }
    }
}
